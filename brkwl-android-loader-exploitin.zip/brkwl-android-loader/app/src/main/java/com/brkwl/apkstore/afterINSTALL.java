package com.brkwl.apkstore;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.os.Build;
import android.util.Log;
import android.widget.Toast;

public class afterINSTALL extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        int status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE);
        int sessionId = intent.getIntExtra(PackageInstaller.EXTRA_SESSION_ID, -1);


        if (status == PackageInstaller.STATUS_SUCCESS) {
            showToast("Installation successful!");
        } else {
            showToast("Installation failed!");

            // Retrieve additional error information
            PackageInstaller packageInstaller = context.getPackageManager().getPackageInstaller();
            try {
                PackageInstaller.SessionInfo sessionInfo = packageInstaller.getSessionInfo(sessionId);
                if (sessionInfo != null) {
                    String errorMsg = "Installation failed. Error: " + sessionInfo.getAppPackageName();

                    Log.e("InstallResultReceiver", errorMsg);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }


        }
    }

    private void showToast(final String message) {
        Toast.makeText(MainActivity.THECTX, message, Toast.LENGTH_SHORT).show();
    }
}
